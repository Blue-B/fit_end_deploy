package com.example.demo.Service.Utile;

public interface HasUserId {
    String getUserid();

}
