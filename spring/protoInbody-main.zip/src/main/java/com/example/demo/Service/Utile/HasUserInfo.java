package com.example.demo.Service.Utile;

import com.example.demo.Entity.UserInfo;

public interface HasUserInfo {
    void setUserInfo(UserInfo userInfo);
}