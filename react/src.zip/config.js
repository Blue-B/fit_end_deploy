const config = {
    SERVER_URL: "123.215.51.252:8080",
  };
  
  export default config;